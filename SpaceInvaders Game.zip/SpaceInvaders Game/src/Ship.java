public abstract class Ship extends Drawable {
    public abstract int deadCount();

    public abstract void hitByMissile();

    public abstract void hitSound();

    public abstract void hitImage();
}
